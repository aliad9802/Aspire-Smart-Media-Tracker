export interface User {
  id: string;
  username: string;
  email: string;
}

export interface MediaItem {
  id: string;
  userId: string;
  title: string;
  creator: string;
  type: 'movie' | 'music' | 'game';
  releaseYear: number;
  genre: string;
  status: 'owned' | 'wishlist' | 'currently-using' | 'completed';
  notes?: string;
  rating?: number;
  poster?: string;
  plot?: string;
  runtime?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Analytics {
  totalItems: number;
  byStatus: {
    owned: number;
    wishlist: number;
    currentlyUsing: number;
    completed: number;
  };
  byType: {
    movie: number;
    music: number;
    game: number;
  };
  recentItems: MediaItem[];
}

export interface AuthResponse {
  message: string;
  token: string;
  user: User;
}