import { useState, useEffect } from 'react';
import { MediaItem } from '../types';

export const useMediaItems = () => {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMediaItems = async () => {
    try {
      setIsLoading(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch('/api/media', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch media items');
      }

      const data = await response.json();
      setMediaItems(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const addMediaItem = async (item: Omit<MediaItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch('/api/media', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(item),
      });

      if (!response.ok) {
        throw new Error('Failed to add media item');
      }

      const newItem = await response.json();
      setMediaItems(prev => [...prev, newItem]);
      return newItem;
    } catch (err) {
      throw err;
    }
  };

  const updateMediaItem = async (id: string, updates: Partial<MediaItem>) => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`/api/media/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });

      if (!response.ok) {
        throw new Error('Failed to update media item');
      }

      const updatedItem = await response.json();
      setMediaItems(prev => prev.map(item => item.id === id ? updatedItem : item));
      return updatedItem;
    } catch (err) {
      throw err;
    }
  };

  const deleteMediaItem = async (id: string) => {
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`/api/media/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to delete media item');
      }

      setMediaItems(prev => prev.filter(item => item.id !== id));
    } catch (err) {
      throw err;
    }
  };

  const fetchMetadata = async (title: string, type: string) => {
    try {
      const response = await fetch(`/api/metadata/${encodeURIComponent(title)}?type=${type}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch metadata');
      }

      return await response.json();
    } catch (err) {
      throw err;
    }
  };

  const searchMetadata = async (query: string, type?: string) => {
    try {
      const typeParam = type ? `?type=${type}` : '';
      const response = await fetch(`/api/metadata/search/${encodeURIComponent(query)}${typeParam}`);
      
      if (!response.ok) {
        throw new Error('Failed to search metadata');
      }

      return await response.json();
    } catch (err) {
      throw err;
    }
  };

  useEffect(() => {
    fetchMediaItems();
  }, []);

  return {
    mediaItems,
    isLoading,
    error,
    addMediaItem,
    updateMediaItem,
    deleteMediaItem,
    fetchMetadata,
    searchMetadata,
    refetch: fetchMediaItems
  };
};