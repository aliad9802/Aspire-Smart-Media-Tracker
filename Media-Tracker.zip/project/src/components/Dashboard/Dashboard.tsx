import React from 'react';
import { useAnalytics } from '../../hooks/useAnalytics';
import StatsCard from './StatsCard';
import { Package, Heart, PlayCircle, CheckCircle, Film, Music, Gamepad2 } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { analytics, isLoading } = useAnalytics();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, index) => (
          <div key={index} className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 animate-pulse">
            <div className="h-4 bg-white/20 rounded w-3/4 mb-2"></div>
            <div className="h-8 bg-white/20 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (!analytics) {
    return null;
  }

  const statusCards = [
    {
      title: 'Total Items',
      value: analytics.totalItems,
      icon: Package,
      color: 'bg-gradient-to-br from-blue-500 to-blue-600',
    },
    {
      title: 'Wishlist',
      value: analytics.byStatus.wishlist,
      icon: Heart,
      color: 'bg-gradient-to-br from-pink-500 to-pink-600',
    },
    {
      title: 'Currently Using',
      value: analytics.byStatus.currentlyUsing,
      icon: PlayCircle,
      color: 'bg-gradient-to-br from-orange-500 to-orange-600',
    },
    {
      title: 'Completed',
      value: analytics.byStatus.completed,
      icon: CheckCircle,
      color: 'bg-gradient-to-br from-green-500 to-green-600',
    },
  ];

  const typeCards = [
    {
      title: 'Movies',
      value: analytics.byType.movie,
      icon: Film,
      color: 'bg-gradient-to-br from-purple-500 to-purple-600',
    },
    {
      title: 'Music',
      value: analytics.byType.music,
      icon: Music,
      color: 'bg-gradient-to-br from-teal-500 to-teal-600',
    },
    {
      title: 'Games',
      value: analytics.byType.game,
      icon: Gamepad2,
      color: 'bg-gradient-to-br from-indigo-500 to-indigo-600',
    },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statusCards.map((card) => (
          <StatsCard
            key={card.title}
            title={card.title}
            value={card.value}
            icon={card.icon}
            color={card.color}
          />
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {typeCards.map((card) => (
          <StatsCard
            key={card.title}
            title={card.title}
            value={card.value}
            icon={card.icon}
            color={card.color}
          />
        ))}
      </div>

      {analytics.recentItems.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">Recent Items</h3>
          <div className="space-y-3">
            {analytics.recentItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    item.status === 'completed' ? 'bg-green-500' :
                    item.status === 'currently-using' ? 'bg-orange-500' :
                    item.status === 'wishlist' ? 'bg-pink-500' :
                    'bg-blue-500'
                  }`}></div>
                  <div>
                    <p className="text-white font-medium">{item.title}</p>
                    <p className="text-gray-400 text-sm">{item.creator} • {item.type}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-gray-300 text-sm capitalize">{item.status.replace('-', ' ')}</p>
                  <p className="text-gray-400 text-xs">{item.releaseYear}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;