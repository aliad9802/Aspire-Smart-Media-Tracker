import React, { useState, useEffect } from 'react';
import { MediaItem } from '../../types';
import { useMediaItems } from '../../hooks/useMediaItems';
import { X, Sparkles, Loader2, Search } from 'lucide-react';

interface MediaFormProps {
  item?: MediaItem;
  onClose: () => void;
  onSave: () => void;
}

interface SearchSuggestion {
  title: string;
  year: string;
  type: string;
  poster: string | null;
  imdbID: string | null;
}

const MediaForm: React.FC<MediaFormProps> = ({ item, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    title: '',
    creator: '',
    type: 'movie' as 'movie' | 'music' | 'game',
    releaseYear: new Date().getFullYear(),
    genre: '',
    status: 'wishlist' as 'owned' | 'wishlist' | 'currently-using' | 'completed',
    notes: '',
    rating: 0,
    plot: '',
    poster: '',
    runtime: ''
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isFetchingMetadata, setIsFetchingMetadata] = useState(false);
  const [searchSuggestions, setSearchSuggestions] = useState<SearchSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const { addMediaItem, updateMediaItem, fetchMetadata, searchMetadata } = useMediaItems();

  useEffect(() => {
    if (item) {
      setFormData({
        title: item.title,
        creator: item.creator,
        type: item.type,
        releaseYear: item.releaseYear,
        genre: item.genre,
        status: item.status,
        notes: item.notes || '',
        rating: item.rating || 0,
        plot: item.plot || '',
        poster: item.poster || '',
        runtime: item.runtime || ''
      });
    }
  }, [item]);

  const handleTitleSearch = async (query: string) => {
    if (query.length < 2 || formData.type !== 'movie') {
      setSearchSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    try {
      const suggestions = await searchMetadata(query, formData.type);
      setSearchSuggestions(suggestions);
      setShowSuggestions(true);
    } catch (error) {
      console.error('Error searching metadata:', error);
      setSearchSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    handleInputChange(e); // Use the existing handler to update formData

    // Clear existing timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    // Only search for movies
    if (formData.type === 'movie') {
      // Set new timeout for debounced search
      const newTimeout = setTimeout(() => {
        handleTitleSearch(value);
      }, 300);

      setSearchTimeout(newTimeout);
    } else {
      // Clear suggestions for non-movie types
      setSearchSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    handleInputChange(e);
    // Clear suggestions when type changes
    setSearchSuggestions([]);
    setShowSuggestions(false);
    
    // If there's a title and new type is movie, search again
    if (formData.title.length >= 2 && e.target.value === 'movie') {
      setTimeout(() => {
        handleTitleSearch(formData.title);
      }, 100);
    }
  };
  const handleSuggestionSelect = async (suggestion: SearchSuggestion) => {
    setFormData(prev => ({ ...prev, title: suggestion.title }));
    setShowSuggestions(false);
    setSearchSuggestions([]);

    // Auto-fill metadata for the selected suggestion
    setIsFetchingMetadata(true);
    try {
      const metadata = await fetchMetadata(suggestion.title, formData.type);
      setFormData(prev => ({
        ...prev,
        ...metadata,
        // Don't override user's status and notes
        status: prev.status,
        notes: prev.notes
      }));
    } catch (error) {
      console.error('Error fetching metadata for suggestion:', error);
    } finally {
      setIsFetchingMetadata(false);
    }
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (item) {
        await updateMediaItem(item.id, formData);
      } else {
        await addMediaItem(formData);
      }
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving media item:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAIFetch = async () => {
    if (!formData.title || !formData.type) return;

    setIsFetchingMetadata(true);
    try {
      const metadata = await fetchMetadata(formData.title, formData.type);
      setFormData(prev => ({
        ...prev,
        ...metadata,
        // Don't override user's status and notes
        status: prev.status,
        notes: prev.notes
      }));
    } catch (error) {
      console.error('Error fetching metadata:', error);
    } finally {
      setIsFetchingMetadata(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'releaseYear' || name === 'rating' ? Number(value) : value
    }));
  };

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setShowSuggestions(false);
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-white/20">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">
            {item ? 'Edit Media Item' : 'Add New Media Item'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Title *
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleTitleChange}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Start typing to search..."
                  required
                />
              </div>
              
              {showSuggestions && searchSuggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-white/10 backdrop-blur-lg border border-white/20 rounded-xl shadow-2xl max-h-60 overflow-y-auto">
                  {searchSuggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSuggestionSelect(suggestion);
                      }}
                      className="w-full text-left px-4 py-3 hover:bg-white/10 transition-colors border-b border-white/10 last:border-b-0 flex items-center space-x-3"
                    >
                      {suggestion.poster && (
                        <img
                          src={suggestion.poster}
                          alt={suggestion.title}
                          className="w-10 h-14 object-cover rounded"
                        />
                      )}
                      <div className="flex-1">
                        <p className="text-white font-medium">{suggestion.title}</p>
                        <p className="text-gray-400 text-sm">{suggestion.year} • {suggestion.type}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Type *
              </label>
              <select
                name="type"
                value={formData.type}
                onChange={handleTypeChange}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="movie" className="bg-gray-800 text-white">Movie</option>
                <option value="music" className="bg-gray-800 text-white">Music</option>
                <option value="game" className="bg-gray-800 text-white">Game</option>
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleAIFetch}
              disabled={!formData.title || !formData.type || isFetchingMetadata}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:from-purple-600 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            >
              {isFetchingMetadata ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>AI Auto-fill</span>
            </button>
            <p className="text-gray-400 text-sm">Fill in title and type, then click to auto-complete</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Creator *
              </label>
              <input
                type="text"
                name="creator"
                value={formData.creator}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Director, Artist, Developer"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Release Year *
              </label>
              <input
                type="number"
                name="releaseYear"
                value={formData.releaseYear}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                min="1900"
                max={new Date().getFullYear() + 10}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Genre *
              </label>
              <input
                type="text"
                name="genre"
                value={formData.genre}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Action, Rock, RPG, etc."
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Status *
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="wishlist" className="bg-gray-800 text-white">Wishlist</option>
                <option value="owned" className="bg-gray-800 text-white">Owned</option>
                <option value="currently-using" className="bg-gray-800 text-white">Currently Using</option>
                <option value="completed" className="bg-gray-800 text-white">Completed</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Rating (1-10)
            </label>
            <input
              type="number"
              name="rating"
              value={formData.rating}
              onChange={handleInputChange}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              min="0"
              max="10"
              step="0.1"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Plot/Description
            </label>
            <textarea
              name="plot"
              value={formData.plot}
              onChange={handleInputChange}
              rows={3}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Brief description or plot summary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Personal Notes
            </label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              rows={3}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Your personal thoughts, where you got it, etc."
            />
          </div>

          <div className="flex items-center space-x-4 pt-4">
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium py-3 px-6 rounded-xl hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-transparent transition-all duration-200 disabled:opacity-50"
            >
              {isLoading ? 'Saving...' : item ? 'Update Item' : 'Add Item'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 bg-gray-500/20 hover:bg-gray-500/30 text-gray-300 rounded-xl transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MediaForm;