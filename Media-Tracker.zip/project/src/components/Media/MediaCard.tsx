import React from 'react';
import { MediaItem } from '../../types';
import { Edit2, Trash2, Calendar, User, Tag, Star } from 'lucide-react';

interface MediaCardProps {
  item: MediaItem;
  onEdit: (item: MediaItem) => void;
  onDelete: (id: string) => void;
}

const MediaCard: React.FC<MediaCardProps> = ({ item, onEdit, onDelete }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'currently-using': return 'bg-orange-500';
      case 'wishlist': return 'bg-pink-500';
      case 'owned': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'movie': return '🎬';
      case 'music': return '🎵';
      case 'game': return '🎮';
      default: return '📦';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-200 group">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">{getTypeIcon(item.type)}</span>
          <div>
            <h3 className="text-lg font-semibold text-white line-clamp-1">{item.title}</h3>
            <div className="flex items-center space-x-2 text-gray-300 text-sm">
              <User className="w-4 h-4" />
              <span>{item.creator}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(item)}
            className="p-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded-lg transition-colors"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(item.id)}
            className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className={`px-3 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(item.status)}`}>
            {item.status.replace('-', ' ').toUpperCase()}
          </span>
          {item.rating && (
            <div className="flex items-center space-x-1 text-yellow-400">
              <Star className="w-4 h-4 fill-current" />
              <span className="text-sm">{item.rating}</span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-4 text-gray-300 text-sm">
          <div className="flex items-center space-x-1">
            <Calendar className="w-4 h-4" />
            <span>{item.releaseYear}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Tag className="w-4 h-4" />
            <span>{item.genre}</span>
          </div>
        </div>

        {item.plot && (
          <p className="text-gray-300 text-sm line-clamp-3">{item.plot}</p>
        )}

        {item.notes && (
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-gray-300 text-sm">{item.notes}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaCard;