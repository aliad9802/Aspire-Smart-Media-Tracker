import React from 'react';
import { BarChart3, Package, Plus } from 'lucide-react';

interface NavigationProps {
  activeTab: 'dashboard' | 'media';
  onTabChange: (tab: 'dashboard' | 'media') => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'media', label: 'My Media', icon: Package },
  ];

  return (
    <nav className="bg-white/10 backdrop-blur-lg rounded-2xl p-2 border border-white/20 mb-8">
      <div className="flex items-center space-x-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as 'dashboard' | 'media')}
              className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-white/20 text-white shadow-lg'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default Navigation;