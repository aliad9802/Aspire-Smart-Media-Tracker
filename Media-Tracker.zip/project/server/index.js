import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage
let users = [];
let mediaItems = [];

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Auth routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // Check if user already exists
    const existingUser = users.find(user => user.email === email || user.username === username);
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const user = {
      id: uuidv4(),
      username,
      email,
      password: hashedPassword,
      createdAt: new Date().toISOString()
    };
    
    users.push(user);
    
    // Generate token
    const token = jwt.sign(
      { userId: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.status(201).json({
      message: 'User created successfully',
      token,
      user: { id: user.id, username: user.username, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = users.find(user => user.email === email);
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Generate token
    const token = jwt.sign(
      { userId: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, username: user.username, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// AI-powered metadata fetching
app.get('/api/metadata/:title', async (req, res) => {
  try {
    const { title } = req.params;
    const { type } = req.query;
    
    // OMDB API for movies and TV shows
    if (type === 'movie' || type === 'tv') {
      try {
        const response = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=15dfc45b`);
        
        if (response.data.Response === 'True') {
          const metadata = {
            title: response.data.Title,
            creator: response.data.Director || response.data.Writer,
            releaseYear: parseInt(response.data.Year),
            genre: response.data.Genre,
            plot: response.data.Plot,
            poster: response.data.Poster !== 'N/A' ? response.data.Poster : null,
            rating: response.data.imdbRating !== 'N/A' ? response.data.imdbRating : null,
            runtime: response.data.Runtime
          };
          
          return res.json(metadata);
        }
      } catch (error) {
        console.log('OMDB API error:', error.message);
      }
    }
    
    // For games and music, return mock data (in production, you'd use other APIs)
    const mockMetadata = {
      title: title,
      creator: 'Various Artists',
      releaseYear: new Date().getFullYear(),
      genre: type === 'game' ? 'Action' : 'Pop',
      plot: `This is a ${type} titled "${title}".`,
      poster: null,
      rating: null,
      runtime: null
    };
    
    res.json(mockMetadata);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch metadata' });
  }
});

// AI-powered search suggestions
app.get('/api/metadata/search/:query', async (req, res) => {
  try {
    const { query } = req.params;
    const { type } = req.query;
    
    let suggestions = [];
    
    // OMDB API search for movies and TV shows
    if (type === 'movie') {
      try {
        const response = await axios.get(`http://www.omdbapi.com/?s=${encodeURIComponent(query)}&type=movie&apikey=15dfc45b`);
        
        if (response.data.Response === 'True' && Array.isArray(response.data.Search)) {
          suggestions = response.data.Search.slice(0, 5).map(item => ({
            title: item.Title,
            year: item.Year,
            type: item.Type,
            poster: item.Poster !== 'N/A' ? item.Poster : null,
            imdbID: item.imdbID
          }));
        }
      } catch (error) {
        console.log('OMDB API search error:', error.message);
      }
    }
    
    res.json(suggestions);
  } catch (error) {
    console.log('Search endpoint error:', error.message);
    res.json([]);
  }
});

// Media CRUD routes
app.get('/api/media', authenticateToken, (req, res) => {
  try {
    const userMedia = mediaItems.filter(item => item.userId === req.user.userId);
    res.json(userMedia);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/media', authenticateToken, (req, res) => {
  try {
    const mediaItem = {
      id: uuidv4(),
      userId: req.user.userId,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    mediaItems.push(mediaItem);
    res.status(201).json(mediaItem);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

app.put('/api/media/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const mediaIndex = mediaItems.findIndex(item => item.id === id && item.userId === req.user.userId);
    
    if (mediaIndex === -1) {
      return res.status(404).json({ message: 'Media item not found' });
    }
    
    mediaItems[mediaIndex] = {
      ...mediaItems[mediaIndex],
      ...req.body,
      updatedAt: new Date().toISOString()
    };
    
    res.json(mediaItems[mediaIndex]);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

app.delete('/api/media/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const mediaIndex = mediaItems.findIndex(item => item.id === id && item.userId === req.user.userId);
    
    if (mediaIndex === -1) {
      return res.status(404).json({ message: 'Media item not found' });
    }
    
    mediaItems.splice(mediaIndex, 1);
    res.json({ message: 'Media item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Analytics endpoint
app.get('/api/analytics', authenticateToken, (req, res) => {
  try {
    const userMedia = mediaItems.filter(item => item.userId === req.user.userId);
    
    const analytics = {
      totalItems: userMedia.length,
      byStatus: {
        owned: userMedia.filter(item => item.status === 'owned').length,
        wishlist: userMedia.filter(item => item.status === 'wishlist').length,
        currentlyUsing: userMedia.filter(item => item.status === 'currently-using').length,
        completed: userMedia.filter(item => item.status === 'completed').length
      },
      byType: {
        movie: userMedia.filter(item => item.type === 'movie').length,
        music: userMedia.filter(item => item.type === 'music').length,
        game: userMedia.filter(item => item.type === 'game').length
      },
      recentItems: userMedia.slice(-5).reverse()
    };
    
    res.json(analytics);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});